package com.zybooks.project_3_robert_dimaio_option_3.ui.dailyweights;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.project_3_robert_dimaio_option_3.R;

import java.util.ArrayList;

public class DailyWeightRecyclerViewAdapter extends RecyclerView.Adapter<DailyWeightRecyclerViewAdapter.ViewHolder> {
    Context context;
    ArrayList<DailyWeight> dailyWeights;

    public DailyWeightRecyclerViewAdapter(Context context, ArrayList<DailyWeight> dailyWeights) {
        this.context = context;
        this.dailyWeights = dailyWeights;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycler_view_row, parent, false);
        return new DailyWeightRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.weightText.setText(dailyWeights.get(position).getDailyWeight() + " lbs");
        holder.dateText.setText(dailyWeights.get(position).getWeighInDate());
    }

    @Override
    public int getItemCount() {
        return dailyWeights.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView weightText, dateText;
        ImageView imageViewEdit, imageViewDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewEdit = itemView.findViewById(R.id.imageViewEdit);
            imageViewDelete = itemView.findViewById(R.id.imageViewDelete);
            weightText = itemView.findViewById(R.id.textViewDailyWeight);
            dateText = itemView.findViewById(R.id.textViewWeighInDate);
        }
    }
}
