package com.zybooks.project_3_robert_dimaio_option_3.ui.dailyweights;

public class DailyWeight { // class to populate list of daily weights
    String dailyWeight;
    String weighInDate;

    public DailyWeight(String dailyWeight, String weighInDate) {
        this.dailyWeight = dailyWeight;
        this.weighInDate = weighInDate;
    }

    public String getDailyWeight() {
        return dailyWeight;
    }

    public String getWeighInDate() {
        return weighInDate;
    }
}
