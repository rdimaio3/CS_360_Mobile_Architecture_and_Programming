package com.zybooks.project_3_robert_dimaio_option_3.ui.goalweight;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.zybooks.project_3_robert_dimaio_option_3.DBHandler;
import com.zybooks.project_3_robert_dimaio_option_3.R;
import com.zybooks.project_3_robert_dimaio_option_3.databinding.FragmentGoalweightBinding;

public class GoalWeightFragment extends Fragment {

    private FragmentGoalweightBinding binding;
    private EditText goalWeightEdit, editTextPhone;
    private TextView textViewGoalWeight;
    private Button addGoalWeightButton, buttonSubmitSMS;
    private DBHandler dbHandler;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentGoalweightBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        goalWeightEdit = root.findViewById(R.id.editTextGoalWeight);
        addGoalWeightButton = root.findViewById(R.id.buttonGoalWeight);
        textViewGoalWeight = root.findViewById(R.id.textViewGoalWeight);
        editTextPhone = root.findViewById(R.id.editTextPhone);
        buttonSubmitSMS = root.findViewById(R.id.buttonSubmitSMS);

        dbHandler = new DBHandler(getActivity());

        String readGoalWeight = dbHandler.getGoalWeight();
        textViewGoalWeight.setText(readGoalWeight + " lbs");

        addGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalWeight = goalWeightEdit.getText().toString();

                if (goalWeight.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter your goal weight.", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHandler.addGoalWeight(goalWeight);

                String readGoalWeight = dbHandler.getGoalWeight();
                textViewGoalWeight.setText(readGoalWeight + " lbs");

                Toast.makeText(getActivity(), "New goal weight has been entered.", Toast.LENGTH_SHORT).show();
                goalWeightEdit.setText("");

            }
        });

        buttonSubmitSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.SEND_SMS}, 0);
                } else {
                    sendSMS();
                }
            }
        });
        return root;
    }

    private void sendSMS() {
        String phoneNumber = editTextPhone.getText().toString();

        String message = "This is an example of an SMS sent to number: " + phoneNumber;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(requireContext(), "SMS Sent to: " + phoneNumber, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(requireContext(), "SMS Failed to Send", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}