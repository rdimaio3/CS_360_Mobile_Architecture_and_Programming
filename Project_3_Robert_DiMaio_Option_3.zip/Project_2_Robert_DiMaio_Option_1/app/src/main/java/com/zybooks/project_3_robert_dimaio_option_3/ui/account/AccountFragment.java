package com.zybooks.project_3_robert_dimaio_option_3.ui.account;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.zybooks.project_3_robert_dimaio_option_3.DBHandler;
import com.zybooks.project_3_robert_dimaio_option_3.R;
import com.zybooks.project_3_robert_dimaio_option_3.databinding.FragmentAccountBinding;

public class AccountFragment extends Fragment {
    private EditText userNameEdit, passwordEdit;
    private Button addUserButton, userLoginButton;
    private DBHandler dbHandler;
    private FragmentAccountBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAccountBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        userNameEdit = root.findViewById(R.id.editTextUsername);
        passwordEdit = root.findViewById(R.id.editTextPassword);
        addUserButton = root.findViewById(R.id.buttonCreateNewUser);
        userLoginButton = root.findViewById(R.id.buttonLogin);
        dbHandler = new DBHandler(getActivity());

        addUserButton.setOnClickListener(new View.OnClickListener() { // create new user
            @Override
            public void onClick(View v) {
                String userName = userNameEdit.getText().toString();
                String password = passwordEdit.getText().toString();

                if (userName.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter username and password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHandler.addNewUser(userName, password);

                Toast.makeText(getActivity(), "New user has been added.", Toast.LENGTH_SHORT).show();
                userNameEdit.setText("");
                passwordEdit.setText("");
            }
        });

        userLoginButton.setOnClickListener(new View.OnClickListener() { // login and check credentials
            @Override
            public void onClick(View v) {
                String username = userNameEdit.getText().toString().trim();
                String password = passwordEdit.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getContext(), "Please enter username and password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (dbHandler.checkUserLogin(username, password)) {
                    Toast.makeText(getContext(), "Login successful!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(getContext(), "Username or password is invalid.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}