package com.zybooks.project_3_robert_dimaio_option_3.ui.dailyweights;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.zybooks.project_3_robert_dimaio_option_3.DBHandler;
import com.zybooks.project_3_robert_dimaio_option_3.R;
import com.zybooks.project_3_robert_dimaio_option_3.databinding.FragmentDailyweightsBinding;
import com.zybooks.project_3_robert_dimaio_option_3.ui.goalweight.GoalWeightFragment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DailyWeightsFragment extends Fragment {
    private FragmentDailyweightsBinding binding;
    private DailyWeightRecyclerViewAdapter adapter;
    private EditText dailyWeightEdit, dateEdit;
    private Button addDailyWeightButton;
    private DBHandler dbHandler;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentDailyweightsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        dbHandler = new DBHandler(requireContext());

        ArrayList<DailyWeight> dailyWeights = dbHandler.getDailyWeights();

        adapter = new DailyWeightRecyclerViewAdapter(requireContext(), dailyWeights);
        binding.weightList.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.weightList.setAdapter(adapter);

        dailyWeightEdit = root.findViewById(R.id.editTextDailyWeight);
        dateEdit = root.findViewById(R.id.editTextDate);
        addDailyWeightButton = root.findViewById(R.id.buttonDailyWeight);

        // set editDate to today's date by default, formatted to mm/dd/yyyy
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        String formattedDate = dateFormat.format(today);

        dateEdit.setText(formattedDate);

        addDailyWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dailyWeight = dailyWeightEdit.getText().toString();
                String date = dateEdit.getText().toString();

                if (dailyWeight.isEmpty() && date.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter your daily weight.", Toast.LENGTH_SHORT).show();
                    return;
                }
                dbHandler.addNewDailyWeight(dailyWeight, date);

                Toast.makeText(getActivity(), "New daily weight has been entered.", Toast.LENGTH_SHORT).show();
                dailyWeightEdit.setText("");
                dateEdit.setText(formattedDate);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}