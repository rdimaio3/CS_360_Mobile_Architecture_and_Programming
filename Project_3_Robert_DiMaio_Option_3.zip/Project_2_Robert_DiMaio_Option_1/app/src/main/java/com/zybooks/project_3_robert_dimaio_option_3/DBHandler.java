package com.zybooks.project_3_robert_dimaio_option_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.zybooks.project_3_robert_dimaio_option_3.ui.dailyweights.DailyWeight;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper { // class to handle all database operations (account login/verification, entering daily weights, goal weight)

    private static final String DB_NAME = "weightAppDB";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME1 = "usersTable"; // table for usernames and passwords
    private static final String ID_COL = "id";
    private static final String USERNAME_COL = "username";
    private static final String PASSWORD_COL = "password";
    private static final String TABLE_NAME2  = "weightsTable"; // table for daily weigh-ins
    private static final String DAILY_WEIGHT_COL = "dailyWeight";
    private static final String DATE_COL = "date";
    private static final String TABLE_NAME3  = "goalWeightTable"; // table for goal weight
    private static final String GOAL_WEIGHT_COL = "goalWeight";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query1 = "CREATE TABLE " + TABLE_NAME1 + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USERNAME_COL + " TEXT,"
                + PASSWORD_COL + " TEXT)";

        db.execSQL(query1);

        String query2 = "CREATE TABLE " + TABLE_NAME2 + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + DAILY_WEIGHT_COL + " TEXT,"
                + DATE_COL + " TEXT)";

        db.execSQL(query2);

        String query3 = "CREATE TABLE " + TABLE_NAME3 + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + GOAL_WEIGHT_COL + " TEXT)";

        db.execSQL(query3);
    }

    public void addNewUser(String userName, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(USERNAME_COL, userName);
        values.put(PASSWORD_COL, password);

        db.insert(TABLE_NAME1, null, values);

        db.close();
    }

    public boolean checkUserLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME1 +
                " WHERE " + USERNAME_COL + " = ? AND " + PASSWORD_COL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean success = cursor.moveToFirst();
        cursor.close();
        db.close();
        return success;
    }

    public void addNewDailyWeight(String dailyWeight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(DAILY_WEIGHT_COL, dailyWeight);
        values.put(DATE_COL, date);

        db.insert(TABLE_NAME2, null, values);

        db.close();
    }

    public ArrayList<DailyWeight> getDailyWeights() {
        ArrayList<DailyWeight> dailyWeights = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME2 + " ORDER BY " + DATE_COL + " DESC ", null);

        if (cursor.moveToFirst()) {
            do {
                String dailyWeight = cursor.getString(cursor.getColumnIndexOrThrow(DAILY_WEIGHT_COL));
                String weighInDate = cursor.getString(cursor.getColumnIndexOrThrow(DATE_COL));
                dailyWeights.add(new DailyWeight(dailyWeight, weighInDate));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return dailyWeights;
    }

    public void addGoalWeight(String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(GOAL_WEIGHT_COL, goalWeight);

        db.insert(TABLE_NAME3, null, values);

        db.close();
    }

    public String getGoalWeight() {
        String goalWeight = "";
        SQLiteDatabase db = this.getReadableDatabase();

        // Retrieve the latest goal weight
        Cursor cursor = db.rawQuery("SELECT " + GOAL_WEIGHT_COL + " FROM " + TABLE_NAME3 + " ORDER BY " + ID_COL + " DESC LIMIT 1", null);

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getString(cursor.getColumnIndexOrThrow(GOAL_WEIGHT_COL));
        }

        cursor.close();
        db.close();

        return goalWeight;

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME1);
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME3);
        onCreate(db);
    }
}
